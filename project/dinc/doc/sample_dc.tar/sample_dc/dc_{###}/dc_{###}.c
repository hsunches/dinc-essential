/*
 * MOBRIC CONFIDENTIAL
 * ___________________
 *
 * 2013 Mobric Incorporated
 * All Rights Reserved.
 *
 * NOTICE:
 * All information contained herein is, and remains the property of
 * Mobric Incorporated and its suppliers, if any. Dissemination of this
 * information or reproduction of this material is strictly forbidden unless
 * prior written permission is obtained from Mobric Incorporated.
 *
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>

#include "dc_definition.h"

#define CUSTOM_DC_ID		DIN_DC_CUSTOM_BASE + 0
#define CUSTOM_DC_PACKET_ID DIN_PACKET_DC_MSG_BASE + 0

static int dc_report_interval;

int collect_routine_info_callback(dc_routine_context* context, const int report_interval, const int interval_countdown);
int network_entry_complete_callback(dc_routine_context* context, const uint32_t latency);
int server_lookup_success_callback(dc_routine_context* context);
int handover_start_callback(const int64_t timestamp_usec);
int handover_end_callback(const int is_success, const int64_t timestamp_usec, const int64_t latency_usec);
int generate_report_interval_callback(void);
void dc_version_callback(void);
void dc_init_callback(void);
void dc_load_config_callback(const char* path);

uint32_t dc_{###}_id(void) __attribute((used));

int dc_{###}_main(int argc, char *argv[]);

int dc_{###}_main(int argc, char *argv[])
{
	dc_routine_definition def = {};

	def.dc_id = CUSTOM_DC_ID;

	def.dc_init = &dc_init_callback;
	def.dc_version = &dc_version_callback;
	def.dc_load_config = &dc_load_config_callback;

	def.collect_dc_routine_info = &collect_routine_info_callback;
	def.dc_generate_report_interval = &generate_report_interval_callback;

	def.on_network_entry_complete = &network_entry_complete_callback;
	def.on_server_lookup_success = &server_lookup_success_callback;
	def.on_handover_start = &handover_start_callback;
	def.on_handover_end = &handover_end_callback;
	
	return util_start_dc_routine(argc, argv, &def);
}

uint32_t dc_{###}_id(void)
{
	return CUSTOM_DC_ID;
}

void dc_version_callback(void) 
{
	// TODO: You may print out any information of your data collector
}

void dc_init_callback(void) 
{
	// TODO: Initializing your data collector
}

int generate_report_interval_callback(void)
{
	// TODO: You may recalculate and return new data collector report interval
	return dc_report_interval;
}

void dc_load_config_callback(const char *path) 
{
	// TODO: Read config file and retrieve report interval
	char line[256];
	FILE *file;

	file = fopen(path, "r");

	if (file == NULL) 
	{
		return;
	}

	while (fgets(line, sizeof(line), file) != NULL) 
	{
		char *value;
		char *token;

		value = strchr(line, '=');

		if (value == NULL) 
		{
			continue;
		}

		*value++ = 0;
		token = strrchr(value, '\n');

		if (token) 
		{
			*token = 0;
		}

		if (!strcmp(line, "REPORT_INTERVAL")) 
		{
			dc_report_interval = (int)strtol(value, NULL, 10);
			break;
		}
	}
	fclose(file);
}

int collect_routine_info_callback(dc_routine_context* context, const int report_interval, const int interval_countdown) 
{
	// DOTO: You can report data when interval_countdown to zero
	int ret = 0;

	if (interval_countdown == 0)
	{
		uint8_t data[BUF_SIZE];
		ret = context->send_dc_report(CUSTOM_DC_PACKET_ID, DINP_HDR_MASK_UID | DINP_HDR_MASK_LOC, data, 0);
	}
	return ret;
}

int network_entry_complete_callback(dc_routine_context* context, const uint32_t latency)
{
	// TODO: Called when network entry completed
	int ret = 0;
	uint8_t data[BUF_SIZE];
	ret = context->send_dc_connection_history_information(data, 0);

	return ret;
}

int server_lookup_success_callback(dc_routine_context* context)
{
	// TODO: Called when server loopup success
	int ret = 0;

	return ret;
}

int handover_start_callback(const int64_t timestamp_usec) 
{
	// TODO: Called when handover start
	int ret = 0;

	return ret;
}

int handover_end_callback(const int is_success, const int64_t timestamp_usec, const int64_t latency_usec) 
{
	// TODO: Called when handover finish
	int ret = 0;

	return ret;
}
